# 📚 Programme2027 – Program Structure & Language Folders

This directory contains the **full set of thematic chapters** of Programme2027, structured in two languages:
- `/FR/` → original version in French
- `/EN/` → official English translation

---

## 📁 Folder Overview

