# 📚 Programme2027 – Structure du programme / Program Structure

Ce dossier contient la **totalité des chapitres thématiques** du Programme2027, organisés en deux langues :
- `/FR/` → version originale en français
- `/EN/` → traduction officielle en anglais

---

## 📁 Arborescence

